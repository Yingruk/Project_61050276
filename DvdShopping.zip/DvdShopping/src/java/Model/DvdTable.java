/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

/**
 *
 * @author cbsdentp
 */
public class DvdTable {    
    
    public static List<Dvdcatalog> findAllDvd() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("DvdShoppingPU");
        EntityManager em = emf.createEntityManager();
        List<Dvdcatalog> DvdList = null;
        try {
            DvdList = (List<Dvdcatalog>) em.createNamedQuery("Dvdcatalog.findAll").getResultList();
            
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        finally {
            em.close();
            emf.close();
        }
        return DvdList;
    }
    
     public static List<Dvdcatalog> findDvdByQuantity() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("DvdShoppingPU");
        EntityManager em = emf.createEntityManager();
        List<Dvdcatalog> data = null;
        try {
            Query query = em.createNativeQuery ("SELECT * FROM DATACATALOG WHERE quantity IS NOT NULL",Dvdcatalog.class);
            data = (List<Dvdcatalog>)query.getResultList();

        } catch (Exception e) {
            //Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
            throw new RuntimeException(e);
        } finally {
            em.close();
            emf.close();
        }
        return data;
    }
    
    
    public static Dvdcatalog findDvdById(int id) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("DvdShoppingPU");
        EntityManager em = emf.createEntityManager();
        Dvdcatalog dvd = null;
        try {
            dvd = em.find(Dvdcatalog.class, id);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        finally {
            em.close();
            emf.close();
        }
        return dvd;
    }
    
    public static int updateDvd(Dvdcatalog dvd) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("DvdShoppingPU");
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            Dvdcatalog target = em.find(Dvdcatalog.class, dvd.getId());
            if (target == null) {
                return 0;
            }
            target.setQuantity(dvd.getQuantity());
            em.persist(target);
            em.getTransaction().commit();
        } catch (Exception e) {
            em.getTransaction().rollback();
            
        }
        finally {
            em.close();
            emf.close();
        }
        return 1;
        
    }
    
    
}
